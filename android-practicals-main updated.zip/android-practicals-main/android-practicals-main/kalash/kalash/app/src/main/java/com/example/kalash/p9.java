package com.example.kalash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class p9 extends AppCompatActivity {

    EditText user, pass;
    Button login, back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p9);
        init();
        ButtonClicks();
    }

    public void init(){
        user = findViewById(R.id.username);
        pass = findViewById(R.id.password);
        login = findViewById(R.id.login);
        back = findViewById(R.id.back);
    }

    public void ButtonClicks(){
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent i = new Intent(getApplicationContext(), login.class);
                if(user.getText().toString().equals("admin") && pass.getText().toString().equals("admin")){
                    i.putExtra("msg", "Welcome, Admin");
                    startActivity(i);
                }
                else {
                    i.putExtra("msg", "Login Failed");
                    startActivity(i);
                }
            }
        });
    }
}