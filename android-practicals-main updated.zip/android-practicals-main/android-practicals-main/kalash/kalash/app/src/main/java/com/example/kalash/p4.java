package com.example.kalash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class p4 extends AppCompatActivity {

    Button convert,back;
    EditText kg;
    TextView p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p4);
        init();
        ButtonClicks();
    }

    public void init(){
        back = findViewById(R.id.back);
        convert = findViewById(R.id.convert);
        kg = findViewById(R.id.kg);
        p = findViewById(R.id.p);
    }

    public void ButtonClicks(){
        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int k = Integer.parseInt(kg.getText().toString());
                double pounnd = k * 2.2046226;
                p.setText("" + pounnd);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
    }
}