package com.example.kalash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class p5 extends AppCompatActivity {

    Button add, sub, mul, div, back;
    EditText n1,n2;
    TextView res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p5);
        init();
        ButtonClicks();
    }

    public void init(){
        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        mul = findViewById(R.id.mul);
        div = findViewById(R.id.div);
        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        res = findViewById(R.id.res);
    }

    public void ButtonClicks(){
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                res.setText("Result = " + (Integer.parseInt(n1.getText().toString()) + Integer.parseInt(n2.getText().toString())) );
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                res.setText("Result = " + (Integer.parseInt(n1.getText().toString()) - Integer.parseInt(n2.getText().toString())) );
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                res.setText("Result = " + (Integer.parseInt(n1.getText().toString()) / Integer.parseInt(n2.getText().toString())) );
            }
        });

        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                res.setText("Result = " + (Integer.parseInt(n1.getText().toString()) * Integer.parseInt(n2.getText().toString())) );
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
    }
}