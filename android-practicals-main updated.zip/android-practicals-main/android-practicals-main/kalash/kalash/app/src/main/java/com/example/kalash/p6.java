package com.example.kalash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class p6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p6);
        print("Created");
    }

    @Override
    protected void onStart() {
        super.onStart();
        print("Started");
    }

    @Override
    protected void onResume() {
        super.onResume();
        print("Resumed");
    }

    @Override
    protected void onStop() {
        super.onStop();
        print("Stopped");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        print("Restarted");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        print("Destroyed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        print("Paused");
    }

    public void print(String text){
        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_LONG);
    }
}