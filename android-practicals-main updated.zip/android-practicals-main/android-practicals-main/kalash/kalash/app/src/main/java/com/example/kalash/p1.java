package com.example.kalash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class p1 extends AppCompatActivity {

    Button submit,back;
    EditText input;
    TextView lbl,lbl2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p1);
        init();
        ButtonClicks();
    }

    public void init(){
        submit = findViewById(R.id.save);
        input = findViewById(R.id.input);
        lbl = findViewById(R.id.lbl);
        lbl2 = findViewById(R.id.lbl2);
        back = findViewById(R.id.back);
    }

    public void ButtonClicks(){
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lbl.setText(input.getText());
                lbl2.setText("Input was :");
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
    }
}