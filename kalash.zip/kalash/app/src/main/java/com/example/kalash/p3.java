package com.example.kalash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class p3 extends AppCompatActivity {

    Button convert, back;
    EditText f;
    TextView c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p3);
        init();
        ButtonClicks();
    }

    public void init(){
        convert = findViewById(R.id.convert);
        f = findViewById(R.id.f);
        c = findViewById(R.id.celcius);
        back = findViewById(R.id.back);
    }

    public void ButtonClicks(){
        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num = Integer.parseInt(String.valueOf(f.getText()));
                double fah = (double)((num - 32)  * 5/9);
                c.setText(" " + fah);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
    }
}