package com.example.kalash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class p10 extends AppCompatActivity {

    Button call, mail, sms, dial, url, map, cont, cd, logs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p10);
        init();
        ButtonClicks();
    }

    public void init(){
        call = findViewById(R.id.call);
        sms = findViewById(R.id.sms);
        logs = findViewById(R.id.logs);
        cont = findViewById(R.id.cont);
        map = findViewById(R.id.map);
        dial = findViewById(R.id.dial);
        url = findViewById(R.id.url);
        cd = findViewById(R.id.cd);
    }

    public void ButtonClicks(){
        mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Intent.ACTION_SEND);
                intent1.setType("message/rfc822");
                intent1.putExtra(Intent.EXTRA_EMAIL,new String[]{"20bmiit040@gmail.com","kalashshahnvs@gmail.com"});
                intent1.putExtra(Intent.EXTRA_SUBJECT,"Android Mail");
                intent1.putExtra(Intent.EXTRA_TEXT,"Sending Mail Through Andorid");
                startActivity(Intent.createChooser(intent1,"Email via"));
            }
        });

        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(Intent.ACTION_SENDTO);
                intent2.setData(Uri.parse("smsto:"+Uri.encode("tel: +919426921383")));
                intent2.putExtra("sms_body","Android Message");
                startActivity(intent2);
            }
        });

        dial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(Intent.ACTION_DIAL, Uri.parse("tel: +919426921383"));
                startActivity(intent3);
            }
        });

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(Intent.ACTION_CALL, Uri.parse("tel: +919426921383"));
                startActivity(intent4);
            }
        });

        url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent5 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"));
                startActivity(intent5);
            }
        });

        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent6 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/@21.1843631,72.7924497,15z"));
                startActivity(intent6);
            }
        });


    }
}