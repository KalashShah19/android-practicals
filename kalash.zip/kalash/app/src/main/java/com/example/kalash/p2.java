package com.example.kalash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class p2 extends AppCompatActivity {

    Button check,back;
    EditText num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p2);
        init();
        ButtonClicks();
    }

    public void init(){
        check = findViewById(R.id.check);
        back = findViewById(R.id.back);
        num = findViewById(R.id.num);
    }

    public void ButtonClicks(){
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder n = new StringBuilder();
                String str = String.valueOf(num.getText());
                String str2;
                n.append(str);
                str2 = String.valueOf(n.reverse());
                int num1 =  Integer.parseInt(str);
                int num2 = Integer.parseInt(str2);
                if(num1 == num2){
                    Toast.makeText(p2.this,"Its a palindrome",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(p2.this,"Its not a palindrome",Toast.LENGTH_SHORT).show();
                }
            }
        });

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
    }
}